/* ============================================================
   Stock Radar · 前端逻辑（原生 JS，无任何外网依赖）
   ============================================================ */
(function () {
  "use strict";

  var FACTOR_ORDER = ["momentum_7d", "momentum_1m", "activity", "trend", "risk", "valuation"];
  var state = {
    tab: "recommend",
    period: "7",
    factorLabels: {},
    weights: {},
    filter: "",
    rows: [],
    loading: false,
    sources: null,
    pollTimer: null
  };

  /* ---------------- 工具函数 ---------------- */
  function $(id) { return document.getElementById(id); }

  function esc(s) {
    return String(s === null || s === undefined ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }

  function num(v, nd) {
    if (v === null || v === undefined || v === "" || isNaN(v)) return "—";
    var n = Number(v);
    return n.toFixed(nd === undefined ? 2 : nd);
  }

  function pct(v) {
    if (v === null || v === undefined || isNaN(v)) return '<span class="flat">—</span>';
    var n = Number(v);
    var cls = n > 0 ? "up" : (n < 0 ? "down" : "flat");
    var sign = n > 0 ? "+" : "";
    return '<span class="' + cls + '">' + sign + n.toFixed(2) + '%</span>';
  }

  function money(v) {
    if (v === null || v === undefined || isNaN(v)) return "—";
    var n = Number(v);
    if (Math.abs(n) >= 1e8) return (n / 1e8).toFixed(2) + " 亿";
    if (Math.abs(n) >= 1e4) return (n / 1e4).toFixed(2) + " 万";
    return n.toFixed(0);
  }

  function toast(msg, isErr) {
    var el = $("toast");
    el.textContent = msg;
    el.className = "toast" + (isErr ? " err" : "");
    clearTimeout(el._t);
    el._t = setTimeout(function () { el.className = "toast hidden"; }, 3600);
  }

  function getJSON(url, opts) {
    return fetch(url, opts || {}).then(function (r) {
      return r.json().then(function (j) {
        if (!r.ok && !j.message) { j.message = "HTTP " + r.status; }
        return j;
      });
    });
  }

  function debounce(fn, wait) {
    var t;
    return function () {
      var args = arguments, self = this;
      clearTimeout(t);
      t = setTimeout(function () { fn.apply(self, args); }, wait);
    };
  }

  /* ---------------- 顶部状态 ---------------- */
  function loadStatus() {
    return getJSON("/api/status").then(function (res) {
      var c = res.cache || {};
      var chip = $("cacheChip");
      if (!c.snapshot_updated_at) {
        chip.textContent = "尚无缓存，请点击刷新";
        chip.className = "chip chip-warn";
      } else {
        chip.textContent = (c.fresh ? "数据已更新 " : "数据可能过期 ") + (c.snapshot_updated_at || "").replace("T", " ");
        chip.className = "chip " + (c.fresh ? "chip-ok" : "chip-warn");
      }
      $("statUniverse").textContent = c.snapshot_count ? c.snapshot_count.toLocaleString() : "—";
      $("statPool").textContent = c.pool_size ? c.pool_size.toLocaleString() : "—";
      $("statUpdated").textContent = (c.scores_updated_at || c.snapshot_updated_at || "—").replace("T", " ");

      // 数据源标识：K线/实时行情 → 同花顺；全市场列表 → 东方财富
      var src = res.sources || {};
      var act = src.active || {}, lab = src.labels || {};
      state.sources = src;
      var kLabel = act.kline === "ths" ? "同花顺" : "东方财富";
      var sLabel = act.snapshot === "eastmoney" ? "东方财富" : "同花顺";
      var qLabel = act.quote === "ths" ? "同花顺" : "东方财富";
      $("statSource").textContent = "K线 " + kLabel + " / 实时 " + qLabel + " / 列表 " + sLabel;
      $("statSource").title = "评分与K线：" + (lab.kline || "-") + "\n实时行情：" + (lab.quote || "-") +
        "\n全市场列表：" + (lab.snapshot || "-") + "\n" + (src.note || "");

      var rf = res.refresh || {};
      var bar = $("refreshBar");
      if (rf.running) {
        bar.classList.remove("hidden");
        $("refreshFill").style.width = (rf.percent || 0) + "%";
        $("refreshMsg").textContent = rf.message || "刷新中…";
        $("refreshBtn").disabled = true;
        $("refreshBtn").classList.add("loading");
        $("refreshBtnText").textContent = "刷新中";
      } else {
        $("refreshBtn").disabled = false;
        $("refreshBtn").classList.remove("loading");
        $("refreshBtnText").textContent = "刷新数据";
        if (state.pollTimer) {
          clearInterval(state.pollTimer); state.pollTimer = null;
          bar.classList.add("hidden");
          if (rf.stage === "error") { toast("刷新失败：" + (rf.error || "未知错误"), true); }
          else if (rf.stage === "done") { toast(rf.message || "刷新完成"); }
          loadList(true);
        }
      }
      return res;
    }).catch(function (e) { toast("状态获取失败：" + e.message, true); });
  }

  function startPolling() {
    if (state.pollTimer) { return; }
    state.pollTimer = setInterval(loadStatus, 1800);
  }

  /* ---------------- 配置 ---------------- */
  function loadConfig() {
    return getJSON("/api/config").then(function (res) {
      if (!res.ok) return;
      state.factorLabels = res.factor_labels || {};
      state.weights = res.weights || {};
      var html = FACTOR_ORDER.map(function (k) {
        var w = state.weights[k];
        return '<div class="legend-item"><span class="l-weight">权重 ' +
          (w === undefined ? "—" : (w * 100).toFixed(0) + "%") + '</span>' +
          '<div class="l-name">' + esc(state.factorLabels[k] || k) + '</div>' +
          '<div class="l-desc">' + esc(FACTOR_DESC[k] || "") + '</div></div>';
      }).join("");
      $("factorLegend").innerHTML = html;
    });
  }

  var FACTOR_DESC = {
    momentum_7d: "近 7 个交易日累计涨跌幅，反映短期资金动能。",
    momentum_1m: "近 1 个月（约 21 个交易日）累计涨跌幅，反映中期趋势。",
    activity: "量比 + 换手率合成，衡量资金参与活跃度，过高视为过热扣分。",
    trend: "MA5 > MA10 > MA20 多头排列、价格站上均线、MA20 斜率向上。",
    risk: "近 60 交易日年化波动率与最大回撤，数值越低得分越高。",
    valuation: "PE / PB 相对合理性，亏损或过高估值扣分；缺失按中性处理。"
  };

  /* ---------------- 榜单渲染 ---------------- */
  function headers() {
    if (state.tab === "recommend") {
      return ["排名", "股票", "最新价", "今日涨跌", "近7日", "近1月", "综合评分", "因子分布", "操作"];
    }
    var pl = state.period === "7" ? "近7日涨跌幅" : "近1月涨跌幅";
    return ["排名", "股票", "最新价", "今日涨跌", pl, "综合评分", "近7日", "近1月", "操作"];
  }

  function factorMini(factors) {
    return '<div class="factor-mini">' + FACTOR_ORDER.map(function (k) {
      var v = (factors && factors[k] !== undefined) ? factors[k] : 0;
      return '<i title="' + esc(state.factorLabels[k] || k) + '：' + num(v, 0) +
        '"><b style="height:' + Math.max(2, Math.min(100, v)) + '%"></b></i>';
    }).join("") + "</div>";
  }

  function srcSummary() {
    var s = state.sources;
    if (!s || !s.active) return "加载中…";
    var a = s.active;
    var k = a.kline === "ths" ? "同花顺" : "东方财富";
    var q = a.quote === "ths" ? "同花顺" : "东方财富";
    return "日K线与评分 " + k + " / 实时行情 " + q + " / 全市场列表 东方财富";
  }

  function priceCell(r) {
    var rt = r.rt || null;
    var tag = rt ? '<span class="rt-tag" title="同花顺实时行情 ' + esc(rt.quote_time || "") + '">实时</span>' : "";
    return '<span class="price-cell">' + num(r.price, 2) + tag + "</span>";
  }

  function scoreCell(score) {
    var s = score === null || score === undefined ? 0 : Number(score);
    return '<div class="score-cell"><div class="score-bar' + (s >= 75 ? " high" : "") +
      '"><i style="width:' + Math.max(2, Math.min(100, s)) + '%"></i></div>' +
      '<span class="score-num">' + num(score, 1) + '</span></div>';
  }

  function nameCell(r) {
    return '<div class="stock-cell"><div><span class="stock-name">' + esc(r.name) + '</span>' +
      (r.industry ? '<span class="industry-tag">' + esc(r.industry) + '</span>' : "") + '</div>' +
      '<div class="stock-sub">' + esc(r.code) + (r.data_ok === false ? " · 数据不足" : "") + '</div></div>';
  }

  function renderTable() {
    var heads = headers();
    $("mainHead").innerHTML = "<tr>" + heads.map(function (h, i) {
      return '<th class="' + (i < 2 ? "left" : "") + '">' + esc(h) + "</th>";
    }).join("") + "</tr>";

    var rows = state.rows;
    if (state.filter) {
      var f = state.filter.toUpperCase();
      rows = rows.filter(function (r) {
        return (r.name || "").toUpperCase().indexOf(f) >= 0 ||
          (r.code || "").toUpperCase().indexOf(f) >= 0 ||
          (r.industry || "").toUpperCase().indexOf(f) >= 0;
      });
    }

    if (!state.rows.length) {
      $("mainBody").innerHTML = '<tr><td colspan="9" class="empty">暂无数据，请点击右上角「刷新数据」抓取行情。</td></tr>';
      return;
    }
    if (!rows.length) {
      $("mainBody").innerHTML = '<tr><td colspan="9" class="empty">当前榜单内没有匹配「' + esc(state.filter) + '」的股票。</td></tr>';
      return;
    }

    var html = rows.map(function (r, i) {
      var rank = i + 1;
      var badgeCls = rank === 1 ? "rank-1" : rank === 2 ? "rank-2" : rank === 3 ? "rank-3" : "";
      var cells = [
        '<div class="rank-badge ' + badgeCls + '">' + rank + "</div>",
        nameCell(r),
        priceCell(r),
        pct(r.pct_chg)
      ];
      if (state.tab === "recommend") {
        cells.push(pct(r.ret7), pct(r.ret21), scoreCell(r.score), factorMini(r.factors));
      } else {
        cells.push(pct(state.period === "7" ? r.ret7 : r.ret21), scoreCell(r.score), pct(r.ret7), pct(r.ret21));
      }
      cells.push('<button class="link-btn" data-code="' + esc(r.code) + '">详情</button>');
      return "<tr>" + cells.map(function (c, idx) {
        return "<td" + (idx < 2 ? ' class="left"' : "") + ">" + c + "</td>";
      }).join("") + "</tr>";
    }).join("");
    $("mainBody").innerHTML = html;
  }

  function loadList(silent) {
    if (state.loading) return;
    state.loading = true;
    var url, tip = $("boardTip");
    if (state.tab === "recommend") {
      url = "/api/recommend?limit=10";
      tip.innerHTML = "按 0~100 综合评分排序：动量（近7日=5个交易日 / 近1月=21个交易日）、活跃度（量比/换手）、均线多头排列、" +
        "波动率与回撤、PE/PB 估值加权合成。因子分布条形顺序：7日动量 / 1月动量 / 活跃度 / 趋势 / 风险 / 估值。";
    } else {
      url = "/api/rank?period=" + state.period + "&order=" + (state.tab === "gainers" ? "desc" : "asc") + "&limit=50";
      tip.innerHTML = "按候选池内股票的<strong>" + (state.period === "7" ? "近 7 个交易日" : "近 1 个月（约 21 个交易日）") +
        "</strong>区间涨跌幅排序（按实际交易日回溯，前复权价格计算）。";
    }
    tip.innerHTML += '<div class="src-line">数据源：' + esc(srcSummary()) +
      '　·　带 <span class="rt-tag">实时</span> 标记的行为同花顺实时行情（realhead），其余为同花顺日K线收盘价。</div>';
    if (!silent) {
      $("mainBody").innerHTML = '<tr><td colspan="9" class="empty"><div class="spinner"></div>数据加载中…</td></tr>';
    }
    getJSON(url).then(function (res) {
      state.loading = false;
      if (!res.ok) { throw new Error(res.message || "接口返回失败"); }
      state.rows = res.items || [];
      $("listHint").textContent = res.count === 0 ? "缓存中暂无可用记录，请先刷新数据。" : "";
      renderTable();
      if (res.summary) {
        $("statUpdown").textContent = res.summary.up_7d + " 涨 / " + res.summary.down_7d + " 跌";
      }
    }).catch(function (e) {
      state.loading = false;
      $("mainBody").innerHTML = '<tr><td colspan="9" class="empty">加载失败：' + esc(e.message) + "</td></tr>";
      toast("榜单加载失败：" + e.message, true);
    });
  }

  /* ---------------- 详情弹窗 ---------------- */
  function radarSVG(factors) {
    var size = 210, cx = size / 2, cy = size / 2 + 6, R = 72;
    var n = FACTOR_ORDER.length;
    function pt(i, ratio) {
      var ang = -Math.PI / 2 + i * 2 * Math.PI / n;
      return [cx + Math.cos(ang) * R * ratio, cy + Math.sin(ang) * R * ratio];
    }
    var grid = "";
    [0.25, 0.5, 0.75, 1].forEach(function (lvl) {
      var pts = FACTOR_ORDER.map(function (_, i) { return pt(i, lvl).join(","); }).join(" ");
      grid += '<polygon points="' + pts + '" fill="none" stroke="#2a3a58" stroke-width="1"></polygon>';
    });
    FACTOR_ORDER.forEach(function (_, i) {
      var p = pt(i, 1);
      grid += '<line x1="' + cx + '" y1="' + cy + '" x2="' + p[0] + '" y2="' + p[1] + '" stroke="#2a3a58" stroke-width="1"></line>';
    });
    var val = FACTOR_ORDER.map(function (k, i) {
      var v = (factors && factors[k] !== undefined ? factors[k] : 0) / 100;
      return pt(i, Math.max(0.04, v)).join(",");
    }).join(" ");
    var labels = FACTOR_ORDER.map(function (k, i) {
      var p = pt(i, 1.24);
      var anchor = Math.abs(p[0] - cx) < 6 ? "middle" : (p[0] > cx ? "start" : "end");
      return '<text x="' + p[0].toFixed(1) + '" y="' + (p[1] + 4).toFixed(1) + '" fill="#93a4c4" font-size="10.5" text-anchor="' +
        anchor + '">' + esc((state.factorLabels[k] || k).replace(/[（(].*/, "")) + "</text>";
    }).join("");
    return '<svg viewBox="0 0 ' + size + " " + (size + 14) + '" width="' + size + '" height="' + (size + 14) + '">' +
      grid +
      '<polygon points="' + val + '" fill="rgba(43,108,255,.32)" stroke="#5b9bff" stroke-width="2"></polygon>' +
      labels + "</svg>";
  }

  function barList(factors) {
    return '<div class="bar-list">' + FACTOR_ORDER.map(function (k) {
      var v = factors && factors[k] !== undefined ? Number(factors[k]) : 0;
      return '<div class="bar-row"><span class="b-label">' + esc(state.factorLabels[k] || k) +
        '</span><span class="b-track"><i class="b-fill" style="width:' + Math.max(2, Math.min(100, v)) +
        '%"></i></span><span class="b-val">' + num(v, 1) + "</span></div>";
    }).join("") + "</div>";
  }

  function sparkline(bars) {
    if (!bars || bars.length < 2) return "";
    var w = 640, h = 130, pad = 8;
    var closes = bars.map(function (b) { return Number(b.close); });
    var min = Math.min.apply(null, closes), max = Math.max.apply(null, closes);
    var span = (max - min) || 1;
    var pts = closes.map(function (c, i) {
      var x = pad + i * (w - 2 * pad) / (closes.length - 1);
      var y = h - pad - (c - min) / span * (h - 2 * pad);
      return x.toFixed(1) + "," + y.toFixed(1);
    });
    var up = closes[closes.length - 1] >= closes[0];
    var color = up ? "#ff4d5e" : "#17c08a";
    return '<div class="section-h">近 ' + closes.length + " 个交易日收盘走势（前复权，" +
      esc(bars[0].date) + " ~ " + esc(bars[bars.length - 1].date) + "）</div>" +
      '<canvas class="spark" id="sparkCanvas" width="' + w + '" height="' + h + '"></canvas>' +
      '<script type="text/plain" id="sparkData">' + pts.join(" ") + "|" + color + "</script>";
  }

  function drawSpark() {
    var cv = $("sparkCanvas"), dataEl = $("sparkData");
    if (!cv || !dataEl) return;
    var raw = dataEl.textContent.split("|");
    var points = raw[0].trim().split(/\s+/).map(function (p) {
      var a = p.split(","); return [Number(a[0]), Number(a[1])];
    });
    var color = raw[1] || "#5b9bff";
    var ctx = cv.getContext("2d");
    ctx.clearRect(0, 0, cv.width, cv.height);
    var grad = ctx.createLinearGradient(0, 0, 0, cv.height);
    grad.addColorStop(0, color + "55");
    grad.addColorStop(1, color + "00");
    ctx.beginPath();
    ctx.moveTo(points[0][0], cv.height);
    points.forEach(function (p) { ctx.lineTo(p[0], p[1]); });
    ctx.lineTo(points[points.length - 1][0], cv.height);
    ctx.closePath();
    ctx.fillStyle = grad;
    ctx.fill();
    ctx.beginPath();
    points.forEach(function (p, i) { i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]); });
    ctx.strokeStyle = color;
    ctx.lineWidth = 1.8;
    ctx.stroke();
  }

  function openDetail(code) {
    $("modal").classList.remove("hidden");
    $("modalContent").innerHTML = '<div class="empty"><div class="spinner"></div>正在获取 ' + esc(code) + " 的行情与评分…</div>";
    getJSON("/api/stock/" + encodeURIComponent(code)).then(function (res) {
      if (!res.ok) { throw new Error(res.message || "查询失败"); }
      var r = res.item;
      var pos = (r.reasons && r.reasons.pros) || [];
      var neg = (r.reasons && r.reasons.cons) || [];
      var html = "";
      html += '<div class="detail-head"><h3>' + esc(r.name) + '</h3>' +
        '<span class="detail-code">' + esc(r.code) + (r.industry ? " · " + esc(r.industry) : "") + "</span>" +
        '<span class="detail-price">' + num(r.price, 2) + " " + pct(r.pct_chg) + "</span></div>";
      html += '<div class="detail-grid">' +
        cell("综合评分", num(r.score, 1)) +
        cell("近7日涨跌幅（5个交易日）", pct(r.ret7)) +
        cell("近1月涨跌幅（21个交易日）", pct(r.ret21)) +
        cell("接口5日涨跌幅（校验）", pct(r.chg_5d)) +
        cell("60日涨跌幅(接口)", pct(r.chg_60d)) +
        cell("MA5", num(r.ma5, 2)) +
        cell("MA10", num(r.ma10, 2)) +
        cell("MA20", num(r.ma20, 2)) +
        cell("均线多头排列", r.ma_bull ? '<span class="up">是</span>' : '<span class="flat">否</span>') +
        cell("量比", num(r.volume_ratio, 2)) +
        cell("换手率", r.turnover === null ? "—" : num(r.turnover, 2) + "%") +
        cell("成交额", money(r.amount)) +
        cell("年化波动率", r.volatility === null ? "—" : num(r.volatility, 1) + "%") +
        cell("最大回撤", r.max_drawdown === null ? "—" : num(r.max_drawdown, 1) + "%") +
        cell("市盈率(动)", num(r.pe, 2)) +
        cell("市净率", num(r.pb, 2)) +
        cell("总市值", money(r.total_mv)) +
        cell("流通市值", money(r.circ_mv)) +
        "</div>";
      var q = r.quote || {};
      if (q && q.price !== undefined && q.price !== null) {
        html += '<div class="section-h">实时行情（' +
          esc(q.source === "ths" ? "同花顺 realhead" : "东方财富") + "）</div>" +
          '<div class="detail-grid">' +
          cell("最新价", num(q.price, 2) + " " + pct(q.pct_chg)) +
          cell("今开", num(q.open, 2)) +
          cell("最高", num(q.high, 2)) +
          cell("最低", num(q.low, 2)) +
          cell("昨收", num(q.prev_close, 2)) +
          cell("成交量", money(q.volume)) +
          cell("成交额", money(q.amount)) +
          cell("行情时间", esc(q.quote_time || "—")) +
          "</div>";
      } else if (q && q.error) {
        html += '<div class="section-h">实时行情</div><div class="board-tip">实时行情获取失败：' + esc(q.error) + "</div>";
      }
      html += '<div class="section-h">评分因子雷达</div><div class="radar-wrap">' +
        radarSVG(r.factors) + barList(r.factors) + "</div>";
      html += sparkline(r.bars);
      html += '<div class="section-h">模型解读</div><ul class="reason-list pos">' +
        (pos.length ? pos.map(function (t) { return "<li>" + esc(t) + "</li>"; }).join("") : "<li>暂无明显加分项</li>") +
        "</ul>";
      if (neg.length) {
        html += '<div class="section-h">风险提示</div><ul class="reason-list neg">' +
          neg.map(function (t) { return "<li>" + esc(t) + "</li>"; }).join("") + "</ul>";
      }
      html += '<div class="section-h">数据说明</div><div class="board-tip">前复权日K线来自' +
        esc(r.kline_source === "ths" ? "同花顺 d.10jqka.com.cn（01/年.js）" : "东方财富 push2his（klt=101, fqt=1）") +
        '，区间涨跌幅与均线均由该K线计算，数据截至 ' + esc(r.last_date || "—") + "，共 " +
        (r.bars_count || r.bars && r.bars.length || 60) + " 个交易日参与计算。" +
        "评分仅基于历史行情量化排序，不构成投资建议。</div>";
      $("modalContent").innerHTML = html;
      drawSpark();
    }).catch(function (e) {
      $("modalContent").innerHTML = '<div class="empty">加载失败：' + esc(e.message) + "</div>";
    });
  }

  function cell(k, v) {
    return '<div class="detail-cell"><div class="k">' + esc(k) + '</div><div class="v">' + v + "</div></div>";
  }

  /* ---------------- 搜索 ---------------- */
  function doSearch() {
    var q = $("searchInput").value.trim();
    if (!q) { toast("请输入股票名称或代码", true); return; }
    var box = $("suggestBox");
    box.classList.remove("hidden");
    box.innerHTML = '<div class="suggest-item"><span class="s-name"><span class="spinner"></span>检索中…</span></div>';
    getJSON("/api/search?q=" + encodeURIComponent(q) + "&limit=8").then(function (res) {
      if (!res.ok) { throw new Error(res.message || "检索失败"); }
      if (!res.items || !res.items.length) {
        box.innerHTML = '<div class="suggest-item"><span class="s-name">' +
          esc(res.message || "未找到匹配股票") + "</span></div>";
        return;
      }
      box.innerHTML = res.items.map(function (r) {
        return '<div class="suggest-item" data-code="' + esc(r.code) + '">' +
          '<span class="s-name">' + esc(r.name) + '<span class="s-code">' + esc(r.code) +
          (r.industry ? " · " + esc(r.industry) : "") + '</span></span>' +
          '<span class="s-pct">' + (r.price === null || r.price === undefined ? "" : num(r.price, 2)) + " " + pct(r.pct_chg) + "</span></div>";
      }).join("");
      var first = res.items[0];
      if (first && first.score !== null && first.score !== undefined) {
        openDetail(first.code);
        box.classList.add("hidden");
      }
    }).catch(function (e) {
      box.innerHTML = '<div class="suggest-item"><span class="s-name">检索失败：' + esc(e.message) + "</span></div>";
    });
  }

  function bindSuggest() {
    var box = $("suggestBox");
    box.addEventListener("click", function (ev) {
      var item = ev.target.closest(".suggest-item");
      if (!item || !item.dataset.code) return;
      box.classList.add("hidden");
      openDetail(item.dataset.code);
    });
    document.addEventListener("click", function (ev) {
      if (!ev.target.closest(".search-wrap")) box.classList.add("hidden");
    });
  }

  /* ---------------- 事件绑定 ---------------- */
  function bindEvents() {
    $("tabs").addEventListener("click", function (ev) {
      var btn = ev.target.closest(".tab");
      if (!btn) return;
      [].forEach.call(this.querySelectorAll(".tab"), function (b) { b.classList.remove("active"); });
      btn.classList.add("active");
      state.tab = btn.dataset.tab;
      $("periodSeg").style.visibility = state.tab === "recommend" ? "hidden" : "visible";
      loadList(false);
    });

    $("periodSeg").addEventListener("click", function (ev) {
      var btn = ev.target.closest(".seg");
      if (!btn) return;
      [].forEach.call(this.querySelectorAll(".seg"), function (b) { b.classList.remove("active"); });
      btn.classList.add("active");
      state.period = btn.dataset.period;
      loadList(false);
    });

    $("listFilter").addEventListener("input", debounce(function () {
      state.filter = this.value.trim();
      renderTable();
    }, 180));

    $("refreshBtn").addEventListener("click", function () {
      var btn = this;
      btn.disabled = true;
      getJSON("/api/refresh", { method: "POST" }).then(function (res) {
        toast(res.message || "刷新任务已启动");
        $("refreshBar").classList.remove("hidden");
        startPolling();
        loadStatus();
      }).catch(function (e) {
        btn.disabled = false;
        toast("启动刷新失败：" + e.message, true);
      });
    });

    $("mainBody").addEventListener("click", function (ev) {
      var btn = ev.target.closest(".link-btn");
      if (btn && btn.dataset.code) openDetail(btn.dataset.code);
    });

    $("modal").addEventListener("click", function (ev) {
      if (ev.target.dataset.close) $("modal").classList.add("hidden");
    });
    document.addEventListener("keydown", function (ev) {
      if (ev.key === "Escape") $("modal").classList.add("hidden");
      if (ev.key === "Enter" && document.activeElement === $("searchInput")) doSearch();
    });

    $("searchBtn").addEventListener("click", doSearch);
    $("searchInput").addEventListener("input", debounce(function () {
      $("searchInput").value.trim() ? doSearch() : $("suggestBox").classList.add("hidden");
    }, 420));
    bindSuggest();
  }

  /* ---------------- 启动 ---------------- */
  function init() {
    bindEvents();
    $("periodSeg").style.visibility = "hidden";
    loadConfig();
    loadStatus().then(function (res) {
      if (res && res.refresh && res.refresh.running) { startPolling(); }
      loadList(false);
    });
  }

  document.addEventListener("DOMContentLoaded", init);
})();
